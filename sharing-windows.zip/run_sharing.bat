@echo off
powershell -STA -ExecutionPolicy Bypass -File "%~dp0sharing_gui.ps1"
