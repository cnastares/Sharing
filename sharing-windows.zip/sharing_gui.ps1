# Configuration
$Port = 15200
$DiscoveryPort = 15201
$MagicPing = "SHARING_PING:"

# Load assemblies
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Create form
$form = New-Object System.Windows.Forms.Form
$form.Text = "Sharing (Continuity Client)"
$form.Size = New-Object System.Drawing.Size(600, 480)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::FromArgb(31, 41, 55) # Dark gray

# Global state
$script:running = $false
$script:client = $null
$script:stream = $null
$script:udpListener = $null
$script:lastType = -1
$script:lastHash = ""

# Console Log TextBox
$console = New-Object System.Windows.Forms.TextBox
$console.Multiline = $true
$console.ReadOnly = $true
$console.ScrollBars = "Vertical"
$console.Size = New-Object System.Drawing.Size(540, 280)
$console.Location = New-Object System.Drawing.Point(20, 100)
$console.BackColor = [System.Drawing.Color]::FromArgb(17, 24, 39) # Darker gray
$console.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219) # Light gray
$console.Font = New-Object System.Drawing.Font("Courier New", 9)
$form.Controls.Add($console)

# Helper to write to console
function Write-Log($msg) {
    $console.AppendText("[ClipSync] $msg`r`n")
}

# Header Label
$header = New-Object System.Windows.Forms.Label
$header.Text = "SHARING CLIENT"
$header.Size = New-Object System.Drawing.Size(400, 30)
$header.Location = New-Object System.Drawing.Point(20, 20)
$header.ForeColor = [System.Drawing.Color]::FromArgb(96, 165, 250) # Glowing blue
$header.Font = New-Object System.Drawing.Font("Helvetica", 14, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($header)

# Info Label
$info = New-Object System.Windows.Forms.Label
$info.Text = "Estado: Detenido"
$info.Size = New-Object System.Drawing.Size(400, 20)
$info.Location = New-Object System.Drawing.Point(20, 55)
$info.ForeColor = [System.Drawing.Color]::FromArgb(156, 163, 175) # Gray
$info.Font = New-Object System.Drawing.Font("Helvetica", 9)
$form.Controls.Add($info)

# Buttons
$startBtn = New-Object System.Windows.Forms.Button
$startBtn.Text = "Iniciar Cliente"
$startBtn.Size = New-Object System.Drawing.Size(120, 30)
$startBtn.Location = New-Object System.Drawing.Point(20, 390)
$startBtn.BackColor = [System.Drawing.Color]::FromArgb(16, 185, 129) # Emerald Green
$startBtn.ForeColor = [System.Drawing.Color]::White
$startBtn.FlatStyle = "Flat"
$startBtn.FlatAppearance.BorderSize = 0
$form.Controls.Add($startBtn)

$stopBtn = New-Object System.Windows.Forms.Button
$stopBtn.Text = "Detener"
$stopBtn.Size = New-Object System.Drawing.Size(100, 30)
$stopBtn.Location = New-Object System.Drawing.Point(150, 390)
$stopBtn.BackColor = [System.Drawing.Color]::FromArgb(239, 68, 68) # Red
$stopBtn.ForeColor = [System.Drawing.Color]::White
$stopBtn.FlatStyle = "Flat"
$stopBtn.FlatAppearance.BorderSize = 0
$stopBtn.Enabled = $false
$form.Controls.Add($stopBtn)

# Helper to compute SHA256 hash of byte array
function Hash($b) { [Convert]::ToBase64String([Security.Cryptography.SHA256]::Create().ComputeHash($b)) }

# Cleanup connection
function Cleanup {
    try { if ($script:stream) { $script:stream.Close(); $script:stream.Dispose() } } catch {}
    try { if ($script:client) { $script:client.Close(); $script:client.Dispose() } } catch {}
    $script:stream = $script:client = $null
}

# Network Loop (runs in a background thread or Timer ticks)
# Windows Forms timer for polling
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 200

$timer.Add_Tick({
    if (-not $script:running) { return }
    
    # 1. Listen UDP for server broadcast if not connected
    if ($script:client -eq $null) {
        $info.Text = "Estado: Buscando equipos..."
        $info.ForeColor = [System.Drawing.Color]::FromArgb(245, 158, 11) # Amber
        try {
            $remoteEP = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, 0)
            if ($script:udpListener.Available -gt 0) {
                $data = $script:udpListener.Receive([ref]$remoteEP)
                $msg = [System.Text.Encoding]::UTF8.GetString($data)
                if ($msg.StartsWith($MagicPing)) {
                    $serverName = $msg.Substring($MagicPing.Length)
                    $serverIP = $remoteEP.Address.ToString()
                    
                    # Connect TCP
                    $script:client = New-Object System.Net.Sockets.TcpClient($serverIP, $Port)
                    $script:stream = $script:client.GetStream()
                    Write-Log "Windows client connected."
                    $info.Text = "Estado: Conectado a $serverName"
                    $info.ForeColor = [System.Drawing.Color]::FromArgb(16, 185, 129) # Green
                }
            }
        } catch {
            Cleanup
        }
        return
    }
    
    # 2. Read incoming TCP packets from Linux
    try {
        if ($script:client.Available -ge 5) {
            $hdr = New-Object byte[] 5
            $script:stream.Read($hdr, 0, 5) | Out-Null
            $t = $hdr[0]
            
            $lenBytes = [byte[]]$hdr[1..4]
            if ([BitConverter]::IsLittleEndian) { [Array]::Reverse($lenBytes) }
            $len = [BitConverter]::ToUInt32($lenBytes, 0)
            
            if ($len -gt 0 -and $len -lt 100MB) {
                $buf = New-Object byte[] $len
                $r = 0
                while ($r -lt $len) {
                    $r += $script:stream.Read($buf, $r, $len - $r)
                }
                
                $script:lastType = $t
                $script:lastHash = Hash $buf
                
                if ($t -eq 0) { # Text
                    $text = [System.Text.Encoding]::UTF8.GetString($buf)
                    Write-Log "Writing text to Windows: '$text'"
                    [System.Windows.Forms.Clipboard]::SetText($text)
                }
                elseif ($t -eq 1) { # Image
                    Write-Log "Writing image to Windows ($($buf.Length) bytes)"
                    $ms = New-Object System.IO.MemoryStream(,$buf)
                    $img = [System.Drawing.Image]::FromStream($ms)
                    [System.Windows.Forms.Clipboard]::SetImage($img)
                    $img.Dispose()
                    $ms.Dispose()
                }
                elseif ($t -eq 2) { # File
                    $nameLenBytes = [byte[]]$buf[0..1]
                    if ([BitConverter]::IsLittleEndian) { [Array]::Reverse($nameLenBytes) }
                    $nameLen = [BitConverter]::ToUInt16($nameLenBytes, 0)
                    $nameBytes = [byte[]]$buf[2..(2+$nameLen-1)]
                    $filename = [System.Text.Encoding]::UTF8.GetString($nameBytes)
                    $fileBytes = [byte[]]$buf[(2+$nameLen)..($buf.Length-1)]
                    
                    $desktopPath = [System.Environment]::GetFolderPath("Desktop")
                    $filePath = Join-Path $desktopPath $filename
                    [System.IO.File]::WriteAllBytes($filePath, $fileBytes)
                    
                    Write-Log "Writing file to Windows: '$filename' ($($fileBytes.Length) bytes)"
                    
                    $balloon = New-Object System.Windows.Forms.NotifyIcon
                    $balloon.Icon = [System.Drawing.SystemIcons]::Information
                    $balloon.Visible = $true
                    $balloon.ShowBalloonTip(5000, "Sharing - Recibido", "Se ha recibido el archivo: $filename", [System.Windows.Forms.ToolTipIcon]::Info)
                }
            }
        }
        
        # 3. Check local Windows clipboard changes
        $lt = -1
        $lb = $null
        if ([System.Windows.Forms.Clipboard]::ContainsImage()) {
            $img = [System.Windows.Forms.Clipboard]::GetImage()
            if ($img -ne $null) {
                $ms = New-Object System.IO.MemoryStream
                $img.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
                $lb = $ms.ToArray()
                $lt = 1
                $ms.Dispose()
                $img.Dispose()
            }
        }
        elseif ([System.Windows.Forms.Clipboard]::ContainsText()) {
            $tx = [System.Windows.Forms.Clipboard]::GetText()
            if ($tx -ne $null -and $tx -ne "") {
                $lb = [System.Text.Encoding]::UTF8.GetBytes($tx)
                $lt = 0
            }
        }
        
        if ($lt -ne -1 -and $lb -ne $null) {
            $h = Hash $lb
            if ($lt -ne $script:lastType -or $h -ne $script:lastHash) {
                $script:lastType = $lt
                $script:lastHash = $h
                
                $label = if ($lt -eq 1) { "image" } else { "text" }
                Write-Log "Sending $label to Linux ($($lb.Length) bytes)"
                
                $lenB = [BitConverter]::GetBytes($lb.Length)
                if ([BitConverter]::IsLittleEndian) { [Array]::Reverse($lenB) }
                
                $script:stream.WriteByte($lt) | Out-Null
                $script:stream.Write($lenB, 0, 4) | Out-Null
                $script:stream.Write($lb, 0, $lb.Length) | Out-Null
            }
        }
    }
    catch [System.IO.IOException], [System.Net.Sockets.SocketException] {
        Write-Log "Windows client disconnected."
        Cleanup
    }
    catch {
        # ignore transient clipboard lock errors
    }
})

# Start Action
$startBtn.Add_Click({
    if ($script:running) { return }
    $script:running = $true
    $startBtn.Enabled = $false
    $stopBtn.Enabled = $true
    
    $console.Clear()
    $console.AppendText("PS C:\Users\calif> clipsync.exe`r`n")
    Write-Log "Listening on port $Port..."
    
    # Initialize UDP discovery socket
    $script:udpListener = New-Object System.Net.Sockets.UdpClient($DiscoveryPort)
    $script:udpListener.Client.ReceiveTimeout = 100
    
    # Start timer
    $timer.Start()
})

# Stop Action
$stopBtn.Add_Click({
    if (-not $script:running) { return }
    $script:running = $false
    $startBtn.Enabled = $true
    $stopBtn.Enabled = $false
    
    $timer.Stop()
    Cleanup
    if ($script:udpListener) {
        $script:udpListener.Close()
        $script:udpListener = $null
    }
    
    $info.Text = "Estado: Detenido"
    $info.ForeColor = [System.Drawing.Color]::FromArgb(156, 163, 175)
    Write-Log "Service stopped."
})

# Close Action
$form.Add_FormClosing({
    $timer.Stop()
    Cleanup
    if ($script:udpListener) { $script:udpListener.Close() }
})

# Show Form
$form.ShowDialog()
